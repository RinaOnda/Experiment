#include "../../library/tek_user.h"

#ifndef	BOOL
#define	BOOL	int
#endif
#ifndef	TRUE
#define	TRUE	1
#endif
#ifndef	FALSE
#define	FALSE	0
#endif

void printhelp(void);

int main(int argc, char *argv[]) {

  char	device_ip[25];
  CLINK	*clink;
  int	i;
  BOOL	setup_clink=FALSE;
  strncpy(device_ip,"128.243.74.108",25);
  clink = new CLINK;

  for(i=1;i<argc;i++){
    if(argv[i][0]=='-'){
      if(argv[i][1]=='i'){
	strncpy(device_ip,argv[++i],25);
      }
      if(argv[i][1]=='h'){
	printhelp();
	if (setup_clink==TRUE) {
	  tek_close(device_ip,clink);
	}
	exit(0);
      }
      if (setup_clink==FALSE) {
	if (tek_open(device_ip,clink) != 0) {
	  printf("Quitting...\n");
	  exit(2);
	}
	setup_clink=TRUE;
      }
      if(argv[i][1]=='d'){
	//char buf[256*50];
	//vxi11_send_and_receive(clink, argv[++i], buf, 256*2, VXI11_READ_TIMEOUT);
	//vxi11_send_and_receive(clink, argv[++i], buf, 256*50, VXI11_READ_TIMEOUT*10);
	char buf[256*100];
	vxi11_send_and_receive(clink, argv[++i], buf, 256*100, VXI11_READ_TIMEOUT*10);
	printf("%s\n", buf);
      }
    }
  }

  if (argc==1) {
    printhelp();
  }

  if (setup_clink==TRUE) {
    tek_close(device_ip,clink);
  }
  
}

void printhelp(void){
  printf("\nTektronix AFG 3252 control program\n");
  printf("GPL Matt 2008\n");
  printf("Usage: tek_afg [-ip www.xxx.yyy.zzz] [options] <commands>\n");
  printf("If IP is to be specified, it must be done before options or commands,\n");
  printf("if not specified then default will be used (128.243.74.108).\n\n");
  printf("Options:\n");
  printf("-h help - this help page\n");
  printf("-d \"string\" - send string direct to AFG (see AFG SCPI manual)\n\n");	
}

